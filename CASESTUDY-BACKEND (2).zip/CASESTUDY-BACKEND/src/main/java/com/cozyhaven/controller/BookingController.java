package com.cozyhaven.controller;

import com.cozyhaven.dto.BookingDto;
import com.cozyhaven.dto.BookingRequest;
import com.cozyhaven.entity.Booking;
import com.cozyhaven.entity.User;
import com.cozyhaven.service.BookingService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/bookings")
@CrossOrigin(origins = "http://localhost:4200")
public class BookingController {

    @Autowired
    private BookingService bookingService;

    @PostMapping
    public ResponseEntity<Booking> book(@RequestBody BookingRequest req, Authentication auth) {
        Booking booking = bookingService.bookRoom(
                ((com.cozyhaven.entity.User) auth.getPrincipal()).getId(),
                req.roomId(),
                req.checkInDate(),
                req.checkOutDate(),
                req.adults(),
                req.children()
        );
        return ResponseEntity.ok(booking);
    }

    // ✅ Updated GET to return DTOs
    @GetMapping
    public ResponseEntity<List<BookingDto>> myBookings(Authentication auth) {
        Long userId = ((User) auth.getPrincipal()).getId();
        List<Booking> bookings = bookingService.getUserBookings(userId);
        List<BookingDto> dtoList = bookings.stream()
                .map(BookingDto::fromEntity)
                .toList();
        return ResponseEntity.ok(dtoList);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> cancel(@PathVariable Long id) {
        bookingService.cancelBooking(id);
        return ResponseEntity.noContent().build();
    }
    
    @GetMapping("/hotel/{hotelId}")
    public ResponseEntity<List<BookingDto>> getBookingsByHotel(@PathVariable Long hotelId) {
        List<Booking> bookings = bookingService.getBookingsByHotelId(hotelId);
        List<BookingDto> dtoList = bookings.stream()
                .map(BookingDto::fromEntity)
                .toList();
        return ResponseEntity.ok(dtoList);
    }

}

