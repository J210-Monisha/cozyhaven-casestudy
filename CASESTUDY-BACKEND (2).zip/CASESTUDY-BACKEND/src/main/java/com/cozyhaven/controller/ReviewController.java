package com.cozyhaven.controller;

import com.cozyhaven.dto.ReviewDto;
import com.cozyhaven.dto.ReviewRequest;
import com.cozyhaven.entity.Review;
import com.cozyhaven.service.ReviewService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/reviews")
@CrossOrigin(origins = "http://localhost:4200")
public class ReviewController {

    @Autowired
    private ReviewService reviewService;

    @PostMapping
    public ResponseEntity<?> postReview(@RequestBody ReviewRequest request, Authentication auth) {
        try {
            String username = auth.getName();
            Review saved = reviewService.addReview(request, username);
            return ResponseEntity.ok(ReviewDto.fromEntity(saved));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.internalServerError()
                .body("Something went wrong while saving the review.");
        }
    }

    @GetMapping("/room/{roomId}")
    public List<ReviewDto> getRoomReviews(@PathVariable Long roomId) {
        return reviewService.listRoomReviews(roomId).stream()
                .map(ReviewDto::fromEntity)
                .toList();
    }

    @GetMapping("/hotel/{hotelId}")
    public List<ReviewDto> getHotelReviews(@PathVariable Long hotelId) {
        return reviewService.listReviews(hotelId).stream()
                .map(ReviewDto::fromEntity)
                .toList();
    }
}
