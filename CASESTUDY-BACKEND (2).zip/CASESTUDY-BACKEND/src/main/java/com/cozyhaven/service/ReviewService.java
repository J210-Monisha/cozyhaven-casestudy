package com.cozyhaven.service;

import com.cozyhaven.dto.ReviewRequest;
import com.cozyhaven.entity.*;
import com.cozyhaven.exception.ResourceNotFoundException;
import com.cozyhaven.repository.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReviewService {

    @Autowired private ReviewRepository reviewRepo;
    @Autowired private HotelRepository hotelRepo;
    @Autowired private RoomRepository roomRepo;
    @Autowired private UserRepository userRepo;

    public Review addReview(ReviewRequest request, String username) {
        User user = userRepo.findByUsername(username)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        Hotel hotel = hotelRepo.findById(request.getHotelId())
                .orElseThrow(() -> new ResourceNotFoundException("Hotel not found"));

        Room room = roomRepo.findById(request.getRoomId())
                .orElseThrow(() -> new ResourceNotFoundException("Room not found"));

        Review review = Review.builder()
                .user(user)
                .hotel(hotel)
                .room(room)
                .rating(request.getRating())
                .comment(request.getComment())
                .build();

        return reviewRepo.save(review);
    }

    public List<Review> listReviews(Long hotelId) {
        return reviewRepo.findByHotelId(hotelId);
    }

    public List<Review> listRoomReviews(Long roomId) {
        return reviewRepo.findByRoomId(roomId);
    }

    public List<Review> listAll() {
        return reviewRepo.findAll();
    }
}

