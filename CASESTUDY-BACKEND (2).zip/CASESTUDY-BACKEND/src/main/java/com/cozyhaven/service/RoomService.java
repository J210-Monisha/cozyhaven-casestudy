package com.cozyhaven.service;

import com.cozyhaven.entity.Hotel;
import com.cozyhaven.entity.Room;
import com.cozyhaven.exception.ResourceNotFoundException;
import com.cozyhaven.repository.HotelRepository;
import com.cozyhaven.repository.RoomRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoomService {

    private final RoomRepository roomRepo;
    private final HotelRepository hotelRepo;

    public RoomService(RoomRepository roomRepo, HotelRepository hotelRepo) {
        this.roomRepo = roomRepo;
        this.hotelRepo = hotelRepo;
    }

    /* ---------- create / update ---------- */
    public Room saveRoom(Room room, Long hotelId) {
        Hotel hotel = hotelRepo.findById(hotelId)
                .orElseThrow(() -> new ResourceNotFoundException("Hotel id " + hotelId + " not found"));

        // Set the hotel object to the room
        room.setHotel(hotel);

        // Optional: Check if updating an existing room
        if (room.getId() != null) {
            Room existingRoom = roomRepo.findById(room.getId())
                    .orElseThrow(() -> new ResourceNotFoundException("Room id " + room.getId() + " not found"));

            // Retain hotel association if not changed
            room.setHotel(existingRoom.getHotel());
        }

        return roomRepo.save(room);
    }

    /* ---------- read ---------- */
    public List<Room> findByHotelId(Long hotelId) {
        return roomRepo.findByHotelId(hotelId);
    }

    public Room findById(Long id) {
        return roomRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Room id " + id + " not found"));
    }

    /* ---------- delete ---------- */
    public void delete(Long id) {
        if (!roomRepo.existsById(id)) {
            throw new ResourceNotFoundException("Room id " + id + " not found");
        }
        roomRepo.deleteById(id);
    }
}

