package com.cozyhaven.service;

import com.cozyhaven.dto.*;
import com.cozyhaven.entity.*;
import com.cozyhaven.repository.*;
import com.cozyhaven.config.JwtUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class AuthService {

    @Autowired private AuthenticationManager authManager;
    @Autowired private UserRepository userRepo;
    @Autowired private RoleRepository roleRepo; // ✅ Correctly injected RoleRepository
    @Autowired private JwtUtils jwtUtils;
    @Autowired private PasswordEncoder encoder;

    public void register(SignupRequest dto) {
        if (userRepo.existsByUsername(dto.username())) {
            throw new RuntimeException("Username already taken");
        }

        User user = new User();
        user.setUsername(dto.username());
        user.setEmail(dto.email());
        user.setPassword(encoder.encode(dto.password()));

        // ✅ Fix: use instance of roleRepo instead of static reference
        Role userRole = roleRepo.findByName(RoleEnum.ROLE_USER)
                .orElseThrow(() -> new RuntimeException("User Role not found"));


        user.setRoles(Set.of(userRole));

        userRepo.save(user);
    }

    public JwtResponse login(LoginRequest loginDto) {
        Authentication auth = authManager.authenticate(
            new UsernamePasswordAuthenticationToken(loginDto.username(), loginDto.password())
        );

        User user = (User) auth.getPrincipal();
        String token = jwtUtils.generateJwtToken(user.getUsername());

        return new JwtResponse(
            token,
            "Bearer",
            user.getId(),
            user.getUsername(),
            user.getEmail(),
            user.getRoles().stream()
                .map(role -> role.getName().name()) // .name() if it's Enum
                .collect(Collectors.toSet())
        );
    }
    public boolean sendResetLink(String email) {
        Optional<User> userOpt = userRepo.findByEmail(email);  // ✅ fixed name
        if (userOpt.isEmpty()) return false;

        // You can generate a token here and save it in DB for future use.
        System.out.println("Reset link sent to: " + email);  // stub for now
        return true;
    }

}
