package com.cozyhaven.dto;

import com.cozyhaven.entity.Booking;
import lombok.*;

import java.time.LocalDate;

@Getter @Setter @AllArgsConstructor @NoArgsConstructor @Builder
public class BookingDto {
    private Long id;
    private Long hotelId;
    private Long roomId;
    private String username;
    private String email;
    private String hotelName;
    private String roomType;
    private LocalDate checkInDate;
    private LocalDate checkOutDate;
    private double totalFare;
    private String status;

    public static BookingDto fromEntity(Booking b) {
        return BookingDto.builder()
                .id(b.getId())
                .hotelId(b.getRoom().getHotel().getId())     // ✅ Add hotelId
                .roomId(b.getRoom().getId())                 // ✅ Add roomId
                .hotelName(b.getRoom().getHotel().getName())
                .roomType(b.getRoom().getBedType())
                .checkInDate(b.getCheckInDate())
                .checkOutDate(b.getCheckOutDate())
                .totalFare(b.getTotalFare())
                .status(b.getStatus().name())
                .username(b.getUser().getUsername()) 
                .email(b.getUser().getEmail())
                .build();
    }
}
