package com.cozyhaven.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReviewRequest {
    private String comment;
    private int rating;
    private Long hotelId;
    private Long roomId;
}
