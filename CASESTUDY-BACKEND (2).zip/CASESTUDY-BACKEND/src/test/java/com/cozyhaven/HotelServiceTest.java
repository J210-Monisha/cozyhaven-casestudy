package com.cozyhaven;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import com.cozyhaven.entity.Hotel;
import com.cozyhaven.entity.Room;
import com.cozyhaven.exception.ResourceNotFoundException;
import com.cozyhaven.repository.HotelRepository;
import com.cozyhaven.service.HotelService;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class HotelServiceTest {

    @Mock
    private HotelRepository hotelRepo;

    @InjectMocks
    private HotelService hotelService;

    @Test
    void testSaveHotel() {
        Hotel hotel = new Hotel();
        hotel.setRooms(List.of(new Room()));  // Set rooms

        when(hotelRepo.save(any(Hotel.class))).thenReturn(hotel);

        Hotel saved = hotelService.saveHotel(hotel);

        assertNotNull(saved);
        verify(hotelRepo).save(any(Hotel.class));
    }

    @Test
    void testFindById_NotFound() {
        when(hotelRepo.findById(1L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> hotelService.findById(1L));
    }
}
