export const environment = {
  production: false,
  apiBaseUrl: 'http://localhost:8080/api',  // optional example
  ownerEmail: 'support@cozyhaven.com',
  supportPhone: '+91 98765 43210'
};
