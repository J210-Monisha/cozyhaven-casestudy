import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Home } from './home/home';
import { Login } from './login/login';
import { Register } from './register/register';
import { Userdashboard } from './userdashboard/userdashboard';
import { BookRoom } from './book-room/book-room';
import { ownerdashboard } from './ownerdashboard/ownerdashboard';
import { EditRoom } from './owner/edit-room/edit-room';// adjust path if needed
import { ForgotPassword } from './forgot-password/forgot-password';
import { Logout } from './logout/logout';
import { AddHotel } from './owner/add-hotel/add-hotel';
import { Roomlist } from './roomlist/roomlist';
import { AddRoom } from './owner/add-room/add-room';
import { EditHotel } from './owner/edit-hotel/edit-hotel';
import { Faqs } from './faqs/faqs';
import { About } from './about/about';
import { Contact } from './contact/contact';
import { Terms } from './terms/terms';
import { Admindashboard } from './admindashboard/admindashboard';
import { AuthGuard } from './guards/auth-guard';



const routes: Routes = [
  { path: '', component: Home },
  { path: 'login', component: Login },
  { path: 'register', component: Register },
  { path: 'forgot-password', component: ForgotPassword },

  { path: 'user-dashboard', component: Userdashboard, canActivate: [AuthGuard] },
  { path: 'admindashboard', component: Admindashboard, canActivate: [AuthGuard] },
  { path: 'owner-dashboard', component: ownerdashboard, canActivate: [AuthGuard] },

  { path: 'book-room/:id', component: BookRoom, canActivate: [AuthGuard] },
  { path: 'edit-hotel/:id', component: EditHotel, canActivate: [AuthGuard] },
  { path: 'owner/add-room', component: AddRoom, canActivate: [AuthGuard] },
  { path: 'edit-room/:roomId', component: EditRoom, canActivate: [AuthGuard] },
  { path: 'roomlist/:id', component: Roomlist, canActivate: [AuthGuard] },
  { path: 'owner/add-hotel', component: AddHotel, canActivate: [AuthGuard] },

  { path: 'logout', component: Logout },
  { path: 'hotel/:id/rooms', component: Roomlist }, // If user-accessible, remove guard

  { path: 'faqs', component: Faqs },
  { path: 'about', component: About },
  { path: 'contact', component: Contact },
  { path: 'terms', component: Terms },

  { path: '', redirectTo: 'login', pathMatch: 'full' }
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
