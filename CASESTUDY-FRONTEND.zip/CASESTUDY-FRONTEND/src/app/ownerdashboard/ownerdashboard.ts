import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Room } from '../services/room';

@Component({
  selector: 'app-ownerdashboard',
  standalone: false,
  templateUrl: './ownerdashboard.html',
  styleUrls: ['./ownerdashboard.css']
})
export class ownerdashboard implements OnInit {
  hotels: any[] = [];
  selectedHotelId: number | null = null;
  rooms: { [hotelId: number]: any[] } = {};
  bookings: { [hotelId: number]: any[] } = {};
  roomReviews: { [roomId: number]: any[] } = {};
  newHotel = { name: '', location: '', description: '', amenities: '' };
  editHotelMode = false;

  token = localStorage.getItem('auth-key');
  headers = new HttpHeaders({ Authorization: `Bearer ${this.token}` });
  

  constructor(
    private http: HttpClient,
    private router: Router,
    public room: Room
  ) {}

  ngOnInit(): void {
    this.loadHotels();
  }

  loadHotels() {
    this.http.get<any[]>('http://localhost:8080/api/hotels/owner', { headers: this.headers }).subscribe({
      next: (data) => this.hotels = data,
      error: (err) => console.error('Error loading hotels', err)
    });
  }

  toggleRooms(hotelId: number) {
    if (this.selectedHotelId === hotelId) {
      this.selectedHotelId = null;
    } else {
      this.selectedHotelId = hotelId;
      this.room.getRoomsByHotelId(hotelId).subscribe({
        next: (data) => {
          this.rooms[hotelId] = data;
          data.forEach((room: any) => {
            this.loadReviews(room.id);
          });
        },
        error: (err) => {
          console.error('Error loading rooms', err);
          this.rooms[hotelId] = [];
        }
      });
    }
  }

  loadReviews(roomId: number) {
  this.http.get<any[]>(`http://localhost:8080/api/reviews/room/${roomId}`, { headers: this.headers })
    .subscribe({
      next: (reviews) => this.roomReviews[roomId] = reviews,
      error: (err) => {
        console.error(`Error loading reviews for room ${roomId}`, err);
        this.roomReviews[roomId] = [];
      }
    });
}
  
  
toggleBookings(hotelId: number) {
  if (this.bookings[hotelId]) {
    delete this.bookings[hotelId];
  } else {
    this.http.get<any[]>(`http://localhost:8080/api/bookings/hotel/${hotelId}`, { headers: this.headers })
      .subscribe({
        next: (data) => {
          this.bookings[hotelId] = data;
        },
        error: (err) => {
          if (err.status === 403) {
            alert('Unauthorized to view bookings for this hotel.');
          } else {
            alert('Failed to load bookings.');
            console.error(err);
          }
        }
      });
  }
}


  goToAddHotel() {
    this.router.navigate(['/owner/add-hotel']);
  }

  addRoom(hotelId: number) {
    this.router.navigate(['/owner/add-room'], {
      queryParams: { hotelId }
    });
  }

  editHotel(hotel: any) {
    this.router.navigate(['/edit-hotel', hotel.id]);
  }

  updateHotel() {
    if (!this.selectedHotelId) return;
    this.http.put(`http://localhost:8080/api/hotels/${this.selectedHotelId}`, this.newHotel, { headers: this.headers })
      .subscribe({
        next: () => {
          alert('Hotel updated');
          this.editHotelMode = false;
          this.newHotel = { name: '', location: '', description: '', amenities: '' };
          this.loadHotels();
        },
        error: () => alert('Failed to update hotel')
      });
  }

  deleteHotel(id: number) {
    if (!confirm('Delete this hotel?')) return;
    this.http.delete(`http://localhost:8080/api/hotels/${id}`, { headers: this.headers })
      .subscribe(() => this.loadHotels());
  }

  editRoom(room: any) {
    this.router.navigate(['/edit-room', room.id], {
      queryParams: { hotelId: this.selectedHotelId }
    });
  }

  deleteRoom(id: number) {
    if (!confirm('Delete this room?')) return;
    this.http.delete(`http://localhost:8080/api/rooms/${id}`, { headers: this.headers })
      .subscribe(() => {
        alert('Room deleted');
        if (this.selectedHotelId) this.toggleRooms(this.selectedHotelId); // reload rooms
      });
  }
}

