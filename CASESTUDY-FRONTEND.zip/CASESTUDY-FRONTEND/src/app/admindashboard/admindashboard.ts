import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { Room } from '../services/room';

@Component({
  selector: 'app-admindashboard',
  standalone: false,
  templateUrl: './admindashboard.html',
  styleUrls: ['./admindashboard.css']
})
export class Admindashboard implements OnInit {
  hotels: any[] = [];
  selectedHotelId: number | null = null;
  rooms: { [hotelId: number]: any[] } = {};
  bookings: { [hotelId: number]: any[] } = {};
  roomReviews: { [roomId: number]: any[] } = {};
  role: string = '';

  token = localStorage.getItem('auth-key');
  headers = new HttpHeaders({ Authorization: `Bearer ${this.token}` });

  constructor(
    private http: HttpClient,
    private router: Router,
    public room: Room
  ) {}

  ngOnInit(): void {
    this.loadUserRole();
    this.loadHotels();
  }

  loadUserRole() {
    const storedRoles = localStorage.getItem('roles');
    if (storedRoles) {
      try {
        const rolesArray = JSON.parse(storedRoles);
        if (Array.isArray(rolesArray) && rolesArray.length > 0) {
          this.role = rolesArray[0];
        }
      } catch (e) {
        console.error('Error parsing roles', e);
      }
    }
  }

  loadHotels() {
    this.http.get<any[]>('http://localhost:8080/api/hotels', { headers: this.headers }).subscribe({
      next: (data) => this.hotels = data,
      error: (err) => console.error('Error loading hotels', err)
    });
  }

  toggleRooms(hotelId: number) {
    if (this.selectedHotelId === hotelId) {
      this.selectedHotelId = null;
    } else {
      this.selectedHotelId = hotelId;
      this.room.getRoomsByHotelId(hotelId).subscribe({
        next: (data) => {
          this.rooms[hotelId] = data;
          data.forEach((room: any) => {
            this.loadReviews(room.id);
          });
        },
        error: (err) => {
          console.error('Error loading rooms', err);
          this.rooms[hotelId] = [];
        }
      });
    }
  }

  loadReviews(roomId: number) {
    this.http.get<any[]>(`http://localhost:8080/api/reviews/room/${roomId}`, { headers: this.headers })
      .subscribe({
        next: (reviews) => this.roomReviews[roomId] = reviews,
        error: (err) => {
          console.error(`Error loading reviews for room ${roomId}`, err);
          this.roomReviews[roomId] = [];
        }
      });
  }

  toggleBookings(hotelId: number) {
    if (this.bookings[hotelId]) {
      delete this.bookings[hotelId];
    } else {
      this.http.get<any[]>(`http://localhost:8080/api/bookings/hotel/${hotelId}`, { headers: this.headers })
        .subscribe({
          next: (data) => this.bookings[hotelId] = data,
          error: (err) => {
            alert('Failed to load bookings');
            console.error(err);
          }
        });
    }
  }

  editHotel(hotel: any) {
    this.router.navigate(['/edit-hotel', hotel.id]);
  }

  deleteHotel(id: number) {
    if (!confirm('Delete this hotel?')) return;
    this.http.delete(`http://localhost:8080/api/hotels/${id}`, { headers: this.headers })
      .subscribe(() => this.loadHotels());
  }

  addRoom(hotelId: number) {
    this.router.navigate(['/owner/add-room'], {
      queryParams: { hotelId }
    });
  }

  editRoom(room: any) {
    this.router.navigate(['/edit-room', room.id], {
      queryParams: { hotelId: this.selectedHotelId }
    });
  }

  deleteRoom(id: number) {
    if (!confirm('Delete this room?')) return;
    this.http.delete(`http://localhost:8080/api/rooms/${id}`, { headers: this.headers })
      .subscribe(() => {
        alert('Room deleted');
        if (this.selectedHotelId) this.toggleRooms(this.selectedHotelId);
      });
  }

  bookRoom(roomId: number) {
    this.router.navigate(['/book-room', roomId]);
  }
}


