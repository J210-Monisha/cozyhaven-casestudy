import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-edit-hotel',
  standalone: false,
  templateUrl: './edit-hotel.html',
  styleUrls: ['./edit-hotel.css']  // ✅ Corrected
})
export class EditHotel implements OnInit {
  hotel: any = {};
  id!: number;

  headers = new HttpHeaders({
    Authorization: `Bearer ${localStorage.getItem('auth-key')}`
  });

  constructor(
    private http: HttpClient,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.id = +this.route.snapshot.paramMap.get('id')!;
    this.http.get(`http://localhost:8080/api/hotels/${this.id}`, { headers: this.headers })
      .subscribe(data => this.hotel = data);
  }

  updateHotel() {
    this.http.put(`http://localhost:8080/api/hotels/${this.id}`, this.hotel, { headers: this.headers })
      .subscribe(() => {
        alert('Hotel updated!');
        this.router.navigate(['/owner-dashboard']);
      });
  }
}
