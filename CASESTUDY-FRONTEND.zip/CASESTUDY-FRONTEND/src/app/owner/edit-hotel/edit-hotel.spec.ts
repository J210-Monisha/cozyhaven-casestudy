import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditHotel } from './edit-hotel';

describe('EditHotel', () => {
  let component: EditHotel;
  let fixture: ComponentFixture<EditHotel>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [EditHotel]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EditHotel);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
