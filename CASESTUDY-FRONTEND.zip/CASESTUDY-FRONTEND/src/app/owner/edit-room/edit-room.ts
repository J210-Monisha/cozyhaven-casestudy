import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-edit-room',
  standalone: false,
  templateUrl: './edit-room.html',
  styleUrls: ['./edit-room.css']  // ✅ Fix typo here
})
export class EditRoom implements OnInit {
  room: any = {};
  roomId!: number;
  hotelId!: number;

  headers = new HttpHeaders({
    'Content-Type': 'application/json',
    Authorization: `Bearer ${localStorage.getItem('auth-key')}`
  });

  constructor(private http: HttpClient, private route: ActivatedRoute, private router: Router) {}

  ngOnInit(): void {
    this.roomId = +this.route.snapshot.paramMap.get('roomId')!;
    this.hotelId = +this.route.snapshot.queryParamMap.get('hotelId')!;  // ✅ assumes you are passing ?hotelId= in route

    this.http.get(`http://localhost:8080/api/rooms/${this.roomId}`, { headers: this.headers })
      .subscribe(data => this.room = data);
  }

  updateRoom() {
    const url = `http://localhost:8080/api/rooms/${this.roomId}?hotelId=${this.hotelId}`;

    this.http.put(url, this.room, {
      headers: this.headers
    }).subscribe({
      next: (res) => {
        console.log('Room updated:', res);
        this.router.navigate(['/owner-dashboard']);
      },
      error: (err) => {
        console.error('Error updating room:', err);
      }
    });
  }
}

