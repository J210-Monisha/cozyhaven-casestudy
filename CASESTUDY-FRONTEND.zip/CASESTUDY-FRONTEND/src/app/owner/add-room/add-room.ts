import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-add-room',
  standalone: false,
  templateUrl: './add-room.html',
  styleUrls: ['./add-room.css']
})
export class AddRoom {
  room = {
    roomSize: '',
    bedType: '',
    baseFare: 0,
    maxOccupancy: 1,
    ac: false
  };

  hotelId!: number;
  headers = new HttpHeaders({
    'Content-Type': 'application/json',
    Authorization: `Bearer ${localStorage.getItem('auth-key')}`
  });

  constructor(
    private route: ActivatedRoute,
    private http: HttpClient,
    private router: Router
  ) {
    this.hotelId = +this.route.snapshot.queryParamMap.get('hotelId')!;
  }

  saveRoom() {
    const url = `http://localhost:8080/api/rooms?hotelId=${this.hotelId}`;
    this.http.post(url, this.room, { headers: this.headers })
      .subscribe({
        next: (res) => {
          alert('Room created');
          this.router.navigate(['/owner-dashboard']);
        },
        error: (err) => {
          console.error('Error creating room:', err);
          alert('Failed to create room');
        }
      });
  }
}


