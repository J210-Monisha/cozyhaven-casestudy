import { Component } from '@angular/core';

@Component({
  selector: 'app-terms',
  standalone: false,
  templateUrl: './terms.html',
  styleUrl: './terms.css'
})
export class Terms {

}
