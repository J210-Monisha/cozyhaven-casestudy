
package com.cozyhaven.entity;
import lombok.*;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Room {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "hotel_id", nullable = false)
    @JsonIgnore // Prevent recursion in JSON
    private Hotel hotel;

    @Column(name = "room_size")
    private String roomSize; // e.g., "300 sq ft"

    @Column(name = "bed_type")
    private String bedType; // KING, QUEEN, TWIN

    @Column(name = "max_occupancy_base")
    private int maxOccupancyBase;

    @Column(name = "max_occupancy")
    private int maxOccupancy;

    @Column(name = "base_fare")
    private double baseFare;
    
    @OneToMany(mappedBy = "room", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Booking> bookings;

    private boolean ac;

    private boolean available = true;
    
    /* -------- expose hotelId without serialising hotel again -------- */
    @JsonProperty("hotelId")       // key in JSON output
    public Long getHotelId() {
        return hotel != null ? hotel.getId() : null;
    }
    public List<Booking> getBookings() {
        return bookings;
    }
}
