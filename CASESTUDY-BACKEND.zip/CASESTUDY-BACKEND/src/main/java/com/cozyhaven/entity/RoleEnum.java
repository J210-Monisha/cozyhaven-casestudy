package com.cozyhaven.entity;

public enum RoleEnum {
    ROLE_USER,
    ROLE_OWNER,
    ROLE_ADMIN
}
