package com.cozyhaven;

import com.cozyhaven.config.JwtUtils;
import com.cozyhaven.dto.JwtResponse;
import com.cozyhaven.dto.LoginRequest;
import com.cozyhaven.entity.Role;
import com.cozyhaven.entity.RoleEnum;
import com.cozyhaven.entity.User;
import com.cozyhaven.repository.RoleRepository;
import com.cozyhaven.repository.UserRepository;
import com.cozyhaven.service.AuthService;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.springframework.security.authentication.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
class AuthServiceTest {

    @InjectMocks
    private AuthService authService;

    @Mock private UserRepository userRepo;
    @Mock private RoleRepository roleRepo;
    @Mock private AuthenticationManager authManager;
    @Mock private JwtUtils jwtUtils;
    @Mock private PasswordEncoder encoder;

    @Test
    void testLoginWithExistingOwner() {
        // Arrange
        LoginRequest loginRequest = new LoginRequest("Monisha", "owner123");

        Role role = new Role();
        role.setId(1L);
        role.setName(RoleEnum.ROLE_OWNER);

        User mockUser = new User();
        mockUser.setId(1L);
        mockUser.setUsername("Monisha");
        mockUser.setEmail("owner@gmail.com");
        mockUser.setPassword("encodedPassword");
        mockUser.setRoles(Set.of(role));

        Authentication mockAuth = mock(Authentication.class);
        when(authManager.authenticate(any())).thenReturn(mockAuth);
        when(mockAuth.getPrincipal()).thenReturn(mockUser);
        when(jwtUtils.generateJwtToken("Monisha")).thenReturn("mocked-jwt-token");

        // Act
        JwtResponse response = authService.login(loginRequest);

        // Assert
        assertNotNull(response);
        assertEquals("mocked-jwt-token", response.getToken());
        assertEquals("Monisha", response.getUsername());
        assertEquals("owner@gmail.com", response.getEmail());
        assertTrue(response.getRoles().contains("ROLE_OWNER"));
    }
}

