import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Api } from '../services/api';

@Component({
  selector: 'app-register',
  standalone: false,
  templateUrl: './register.html',
  styleUrls: ['./register.css']
})
export class Register {
  form: FormGroup;
  error: string = '';
  passwordStrength: string = '';
  strengthColor: string = 'black';

  constructor(
    private fb: FormBuilder,
    private api: Api,
    private router: Router
  ) {
    this.form = this.fb.group({
      username: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(8)]]
    });
  }

  checkPasswordStrength() {
    const pwd = this.form.get('password')?.value;
    if (!pwd) {
      this.passwordStrength = '';
      return;
    }

    const strongRegex = /^(?=.*[0-9])(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

    if (strongRegex.test(pwd)) {
      this.passwordStrength = 'Strong password';
      this.strengthColor = 'green';
    } else if (pwd.length >= 6) {
      this.passwordStrength = 'Moderate password';
      this.strengthColor = 'orange';
    } else {
      this.passwordStrength = 'Weak password';
      this.strengthColor = 'red';
    }
  }

  submit() {
    if (this.form.invalid) {
      this.error = "Please fill all fields correctly.";
      return;
    }

    const payload = this.form.value;

    this.api.register(payload).subscribe({
      next: () => {
        this.error = '';
        alert("✅ Registered successfully!");
        this.router.navigate(['/login']);
      },
      error: (err: { error?: { message?: string } }) => {
        console.error("Registration error:", err);
        this.error = err.error?.message || 'Registration failed';
      }
    });
  }
}
