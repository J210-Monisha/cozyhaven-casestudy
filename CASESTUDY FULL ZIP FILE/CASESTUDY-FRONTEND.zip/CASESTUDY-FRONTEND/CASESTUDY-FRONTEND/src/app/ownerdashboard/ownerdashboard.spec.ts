import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ownerdashboard } from './ownerdashboard';

describe('Ownerdashboard', () => {
  let component: ownerdashboard;
  let fixture: ComponentFixture<ownerdashboard>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ownerdashboard]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ownerdashboard);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
