import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Api } from '../services/api'; // Adjust path based on your structure

@Component({
  selector: 'app-forgot-password',
  standalone:false,
  templateUrl: './forgot-password.html',
  styleUrls: ['./forgot-password.css']
})
export class ForgotPassword {
  form: FormGroup;
  successMsg: string = '';
  errorMsg: string = '';

  constructor(private fb: FormBuilder, private api: Api) {
    this.form = this.fb.group({
      email: ['', [Validators.required, Validators.email]]
    });
  }

  submit() {
    if (this.form.invalid) return;

    const email = this.form.value.email;

    this.api.forgotPassword(email).subscribe({
      next: () => {
        this.successMsg = 'Reset link sent to your email.';
        this.errorMsg = '';
      },
      error: (err) => {
        console.error(err);
        this.errorMsg = 'Failed to send reset link.';
        this.successMsg = '';
      }
    });
  }
}
