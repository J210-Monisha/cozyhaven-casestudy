import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class Api {
  private baseUrl = 'http://localhost:8080/api/auth';

  constructor(private http: HttpClient) {}

  // ✅ User Login
  login(payload: { username: string; password: string }) {
    return this.http.post(`${this.baseUrl}/login`, payload);
  }

  // ✅ User Registration
  register(payload: { username: string; email: string; password: string }) {
    return this.http.post(`${this.baseUrl}/register`, payload);
  }

  // ✅ Forgot Password
  forgotPassword(email: string) {
    return this.http.post(`${this.baseUrl}/forgot-password`, { email });
  }

  // 🔒 Optional: Reset Password (requires token + new password)
  resetPassword(token: string, newPassword: string) {
    return this.http.post(`${this.baseUrl}/reset-password`, {
      token,
      newPassword
    });
  }
}

