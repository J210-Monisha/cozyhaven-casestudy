import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class Room {

  private baseUrl = 'http://localhost:8080/api/rooms';

  constructor(private http: HttpClient) {}

  getRoomsByHotelId(hotelId: number): Observable<any[]> {
    const token = localStorage.getItem('auth-key');
    const headers = new HttpHeaders({ Authorization: `Bearer ${token}` });
    return this.http.get<any[]>(`${this.baseUrl}?hotelId=${hotelId}`, { headers });
  }

  getRoomById(roomId: number): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/${roomId}`);
  }
}
