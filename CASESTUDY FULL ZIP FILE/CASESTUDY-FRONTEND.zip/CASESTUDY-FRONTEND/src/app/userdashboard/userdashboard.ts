import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Hotel } from '../services/hotel';
import { Room } from '../services/room';

@Component({
  selector: 'app-userdashboard',
  standalone: false,
  templateUrl: './userdashboard.html',
  styleUrls: ['./userdashboard.css']
})
export class Userdashboard implements OnInit {
  bookings: any[] = [];
  hotels: any[] = [];
  allHotels: any[] = []; // to preserve full hotel list
  searchLocation: string = ''; // search input binding

  imageUrls: string[] = [
    'https://images.pexels.com/photos/261102/pexels-photo-261102.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=200',
    'https://images.pexels.com/photos/271639/pexels-photo-271639.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=200',
    'https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=200',
    'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=200',
    'https://images.pexels.com/photos/261169/pexels-photo-261169.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=200',
    'https://images.pexels.com/photos/326709/pexels-photo-326709.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=200',
    'https://images.pexels.com/photos/237371/pexels-photo-237371.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=200'
  ];

  constructor(
    private hotel: Hotel,
    private room: Room,
    private router: Router,
    private http: HttpClient
  ) {}

  ngOnInit(): void {
    this.hotel.getAllHotels().subscribe({
      next: (data) => {
        this.allHotels = data.map((h, i) => ({
          ...h,
          image: this.imageUrls[i % this.imageUrls.length]
        }));

        this.hotels = [...this.allHotels];
      },
      error: (err) => {
        console.error('Failed to load hotels', err);
      }
    });

    this.loadBookings();
  }

  filterHotels() {
    const search = this.searchLocation.toLowerCase().trim();
    this.hotels = this.allHotels.filter(hotel =>
      hotel.location.toLowerCase().includes(search)
    );
  }

  async loadBookings() {
    const token = localStorage.getItem('auth-key');
    if (!token) return;

    const headers = { Authorization: `Bearer ${token}` };

    try {
      const data = await this.http.get<any[]>('http://localhost:8080/api/bookings', { headers }).toPromise();

      for (const booking of data ?? []) {
        if (booking.hotelId && !booking.hotel) {
          try {
            booking.hotel = await this.http
              .get<any>(`http://localhost:8080/api/hotels/${booking.hotelId}`, { headers })
              .toPromise();
          } catch (err) {
            console.error(`Error fetching hotel ${booking.hotelId}`, err);
          }
        }

        if (booking.roomId && !booking.room) {
          try {
            booking.room = await this.room.getRoomById(booking.roomId).toPromise();
          } catch (err) {
            console.error(`Error fetching room ${booking.roomId}`, err);
          }
        }
      }

      this.bookings = data ?? [];
    } catch (err) {
      console.error('Failed to load bookings', err);
      this.bookings = [];
    }
  }

  seeRooms(hotelId: number) {
    this.router.navigate(['/hotel', hotelId, 'rooms']);
  }

  cancelBooking(id: number) {
    const token = localStorage.getItem('auth-key');
    if (!token) return;

    if (!confirm('Are you sure you want to cancel this booking?')) return;

    this.http.delete(`http://localhost:8080/api/bookings/${id}`, {
      headers: { Authorization: `Bearer ${token}` }
    }).subscribe({
      next: () => {
        alert('Booking cancelled.');
        this.bookings = this.bookings.map(b =>
          b.id === id ? { ...b, status: 'CANCELLED' } : b
        );
      },
      error: (err) => {
        alert('Failed to cancel booking.');
        console.error('Cancellation error:', err);
      }
    });
  }
}


