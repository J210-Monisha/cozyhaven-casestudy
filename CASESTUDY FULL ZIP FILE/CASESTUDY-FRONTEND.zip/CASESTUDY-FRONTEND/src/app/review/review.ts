import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-review',
  standalone: false,
  templateUrl: './review.html',
  styleUrl: './review.css'
})
export class Review {
  @Input() hotelId!: number;
  @Input() roomId!: number; // ✅ Add this line to receive the room ID

  comment: string = '';
  rating: number = 0;

  postReview() {
    const token = localStorage.getItem('auth-key');
    if (!token) return alert('Please login to review.');

    const headers = {
      headers: { Authorization: `Bearer ${token}` }
    };

    const reviewPayload = {
      comment: this.comment,
      rating: this.rating,
      hotelId: this.hotelId,
      roomId: this.roomId
    };

    console.log("Sending Review:", reviewPayload); // ✅ Optional: to verify data

    fetch('http://localhost:8080/api/reviews', {
      method: 'POST',
      headers: {
        ...headers.headers,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(reviewPayload)
    })
      .then(res => {
        if (res.ok) alert('Review posted!');
        else alert('Failed to post review.');
      });
  }
}

