import { Component } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-hotel',
  standalone:false,
  templateUrl: './add-hotel.html',
  styleUrls: ['./add-hotel.css']
})
export class AddHotel {
  hotel = {
    name: '',
    location: '',
    description: '',
    amenities: ''
  };

  // Optional: For file upload later
  // selectedFile: File | null = null;

  token = localStorage.getItem('auth-key');
  headers = new HttpHeaders({ Authorization: `Bearer ${this.token}` });

  constructor(private http: HttpClient, private router: Router) {}

  saveHotel() {
    this.http.post('http://localhost:8080/api/hotels', this.hotel, { headers: this.headers }).subscribe({
      next: () => {
        Swal.fire({
          icon: 'success',
          title: 'Hotel added successfully',
          showConfirmButton: false,
          timer: 2000
        }).then(() => {
          this.router.navigate(['/owner/dashboard']);
        });
      },
      error: () => {
        Swal.fire({
          icon: 'error',
          title: 'Failed to add hotel',
          text: 'Please check the form or try again later'
        });
      }
    });
  }
}
