import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-book-room',
  standalone: false,
  templateUrl: './book-room.html',
  styleUrl: './book-room.css'
})
export class BookRoom implements OnInit {
  roomId!: number;
  successMessage = '';
  booking = {
    checkInDate: '',
    checkOutDate: '',
    adults: 1,
    children: 0
  };

  constructor(private route: ActivatedRoute, private http: HttpClient) {}

  ngOnInit(): void {
    this.roomId = Number(this.route.snapshot.paramMap.get('id'));
  }

  submitBooking() {
    const payload = {
      ...this.booking,
      roomId: this.roomId
    };
const token = localStorage.getItem('auth-key'); // ✅ not 'token'

    const headers = new HttpHeaders({
  'Authorization': `Bearer ${token}`
});


    this.http.post('http://localhost:8080/api/bookings', payload, { headers })
      .subscribe({
        next: () => this.successMessage = 'Room booked successfully!',
        error: (err: any) => {
  console.error('Booking failed', err);
  if (err.error?.message) {
    this.successMessage = `❌ ${err.error.message}`;
  } else {
    this.successMessage = 'Booking failed. Try again.';
  }
}
      }
    )};
  }
    
