import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Room } from '../services/room';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-roomlist',
  standalone: false,
  templateUrl: './roomlist.html',
  styleUrls: ['./roomlist.css']
})
export class Roomlist implements OnInit {
  hotelId!: number;
  rooms: any[] = [];
  filteredRooms: any[] = [];
  bookings: any[] = [];
  reviews: { [roomId: number]: any[] } = {};
  newReview: { [roomId: number]: string } = {};
  newRating: { [roomId: number]: number } = {};

  maxPrice: number = 0;
  role: string = '';

  roomImages: string[] = [
    'https://images.pexels.com/photos/32764943/pexels-photo-32764943.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=200',
    'https://images.pexels.com/photos/14645130/pexels-photo-14645130.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=200',
    'https://arlohotels.com/soho/wp-content/uploads/sites/2/2022/05/two-twin-room-1.jpeg', 
    'https://images.pexels.com/photos/28347471/pexels-photo-28347471.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=200',
    'https://images.pexels.com/photos/14645130/pexels-photo-14645130.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=200',
    'https://images.pexels.com/photos/14917460/pexels-photo-14917460.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=200'
  ];

  constructor(
    private route: ActivatedRoute,
    private roomService: Room,
    private http: HttpClient,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.hotelId = +this.route.snapshot.params['id'];
    this.loadUserRole();
    this.loadRooms();
    this.loadBookings();
  }

  loadUserRole() {
    const storedRoles = localStorage.getItem('roles');
    if (storedRoles) {
      try {
        const rolesArray = JSON.parse(storedRoles);
        if (Array.isArray(rolesArray) && rolesArray.length > 0) {
          this.role = rolesArray[0];
        }
      } catch (e) {
        console.error('Error parsing roles', e);
      }
    }
  }

  loadRooms() {
    this.roomService.getRoomsByHotelId(this.hotelId).subscribe({
      next: (data: any[]) => {
        this.rooms = data.map((room, index) => ({
          ...room,
          image: this.roomImages[index % this.roomImages.length]
        }));
        this.filteredRooms = [...this.rooms];
        data.forEach(room => this.loadReviews(room.id));
      },
      error: (err: any) => console.error('Failed to load rooms', err)
    });
  }

  filterRooms() {
    if (this.maxPrice && this.maxPrice > 0) {
      this.filteredRooms = this.rooms.filter(r => r.baseFare <= this.maxPrice);
    } else {
      this.filteredRooms = [...this.rooms];
    }
  }

  loadBookings() {
    this.http.get<any[]>(`http://localhost:8080/api/hotels/${this.hotelId}/bookings`)
      .subscribe({
        next: (data) => this.bookings = data,
        error: (err) => console.error('Error loading bookings', err)
      });
  }

  loadReviews(roomId: number) {
    this.http.get<any[]>(`http://localhost:8080/api/reviews/room/${roomId}`)
      .subscribe({
        next: (data) => this.reviews[roomId] = data,
        error: (err) => console.error('Error loading reviews for room', roomId, err)
      });
  }

  bookNow(roomId: number) {
    this.router.navigate(['/book-room', roomId]);
  }

  addReview(roomId: number) {
    const token = localStorage.getItem('auth-key');
    if (!token) return alert('Please login to add review.');

    const headers = {
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    };

    const reviewPayload = {
      comment: this.newReview[roomId],
      rating: this.newRating[roomId],
      hotelId: this.hotelId,
      roomId: roomId
    };

    this.http.post('http://localhost:8080/api/reviews', reviewPayload, headers)
      .subscribe({
        next: () => {
          alert('Review added!');
          this.newReview[roomId] = '';
          this.newRating[roomId] = 0;
          this.loadReviews(roomId);
        },
        error: (err) => {
          alert('Failed to post review.');
          console.error(err);
        }
      });
  }

 setRating(roomId: number, value: number) {
  this.newRating[roomId] = value;
}
}
