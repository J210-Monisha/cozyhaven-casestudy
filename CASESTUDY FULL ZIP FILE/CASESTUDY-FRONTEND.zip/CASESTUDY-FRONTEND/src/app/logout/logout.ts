import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-logout',
  standalone:false,
  templateUrl: './logout.html',
  styleUrls: ['./logout.css']
})
export class Logout {

  constructor(private router: Router) {
    this.logout(); // logout when component is loaded
  }

  logout(): void {
    localStorage.removeItem('auth-key');
    localStorage.removeItem('roles');
    localStorage.removeItem('username');

    alert("You have been logged out successfully!");
    this.router.navigate(['/home']);
  }
}

