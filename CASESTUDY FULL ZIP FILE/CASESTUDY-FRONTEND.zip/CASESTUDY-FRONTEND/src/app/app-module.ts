import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing-module';
import { App } from './app';
import { Home } from './home/home';
import { Login } from './login/login';
import { Register } from './register/register';
import { Userdashboard } from './userdashboard/userdashboard';
import { Navbar } from './navbar/navbar';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { Roomlist } from './roomlist/roomlist';
import { BookRoom } from './book-room/book-room';
import { Room } from './services/room';
import { EditHotel } from './owner/edit-hotel/edit-hotel';
import { AddRoom } from './owner/add-room/add-room';
import { EditRoom } from './owner/edit-room/edit-room';
import { ForgotPassword } from './forgot-password/forgot-password';
import { Logout } from './logout/logout';
import { AddHotel } from './owner/add-hotel/add-hotel';
import { ownerdashboard } from './ownerdashboard/ownerdashboard';
import { Faqs } from './faqs/faqs';
import { About } from './about/about';
import { Contact } from './contact/contact';
import { Terms } from './terms/terms';
import { Admindashboard } from './admindashboard/admindashboard';
import { Review } from './review/review';

@NgModule({
  declarations: [
    App,
    Home,
    Login,
    Register,
    Userdashboard,
    ownerdashboard,
    Navbar,
    Roomlist,
    BookRoom,
    Review,
    AddHotel,
    EditHotel,
    AddRoom,
    EditRoom,
    ForgotPassword,
    Logout,
    Faqs,
    About,
    Contact,
    Terms,
    Admindashboard
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    AppRoutingModule
  ],
  providers: [Room], // ✅ keep this empty or add real providers
  bootstrap: [App]
})
export class AppModule { }
