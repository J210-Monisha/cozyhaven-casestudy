import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Api } from '../services/api';

@Component({
  selector: 'app-login',
  standalone: false,
  templateUrl: './login.html',
  styleUrls: ['./login.css']
})
export class Login {
  form!: FormGroup;
  error: string = '';
showPassword: boolean = false;

  constructor(
    private fb: FormBuilder,
    private api: Api,
    private router: Router
  ) {
    this.form = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }
  
  togglePasswordVisibility() {
    this.showPassword = !this.showPassword;
  }

  login() {
    if (this.form.invalid) {
      this.error = "Please enter both username and password.";
      return;
    }

    const payload = this.form.value;

    this.api.login(payload).subscribe({
      next: (res: any) => {
        localStorage.setItem('auth-key', res.token);
        localStorage.setItem('roles', JSON.stringify(Array.from(res.roles)));
        localStorage.setItem('username', res.username);

        const role = Array.from(res.roles)[0];

        alert("✅ Login successful!");

        if (role === 'ROLE_OWNER') {
          this.router.navigate(['/owner-dashboard']);
        } else if (role === 'ROLE_ADMIN') {
          this.router.navigate(['/admindashboard']);
        } else {
          this.router.navigate(['/user-dashboard']);
        }
      },
      error: (err: { error: { message: string } }) => {
        console.error("Login error:", err);
        this.error = err.error?.message || "Login failed";
      }
    });
  }
}


