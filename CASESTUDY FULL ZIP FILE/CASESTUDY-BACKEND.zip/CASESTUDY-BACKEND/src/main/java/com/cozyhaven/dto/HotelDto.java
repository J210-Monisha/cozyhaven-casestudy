package com.cozyhaven.dto;

import com.cozyhaven.entity.Hotel;
import lombok.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class HotelDto {

    private Long id;
    private String name;
    private String location;
    private String description;
    private String amenities;
    private String ownerUsername; // ✅ New field

    public static HotelDto fromEntity(Hotel h) {
        return HotelDto.builder()
                .id(h.getId())
                .name(h.getName())
                .location(h.getLocation())
                .description(h.getDescription())
                .amenities(h.getAmenities())
                .ownerUsername(h.getOwner().getUsername()) // ✅ Include owner name
                .build();
    }
}
