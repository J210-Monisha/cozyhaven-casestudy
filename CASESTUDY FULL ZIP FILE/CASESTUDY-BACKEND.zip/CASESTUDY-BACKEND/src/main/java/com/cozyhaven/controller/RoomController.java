package com.cozyhaven.controller;

import com.cozyhaven.entity.Room;
import com.cozyhaven.service.RoomService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/rooms")
@CrossOrigin(origins = "http://localhost:4200")
public class RoomController {

    private final RoomService roomService;

    public RoomController(RoomService roomService) {
        this.roomService = roomService;
    }

    // Public room list by hotelId
    @PreAuthorize("permitAll()")
    @GetMapping
    public ResponseEntity<List<Room>> listByHotel(@RequestParam Long hotelId) {
        return ResponseEntity.ok(roomService.findByHotelId(hotelId));
    }

    // Get room by ID
    @PreAuthorize("permitAll()")
    @GetMapping("/{id}")
    public ResponseEntity<Room> get(@PathVariable Long id) {
        return ResponseEntity.ok(roomService.findById(id));
    }

    // Add new room
    @PreAuthorize("hasRole('OWNER') or hasRole('ADMIN')")
    @PostMapping
    public ResponseEntity<Room> add(@RequestBody Room room,
                                    @RequestParam Long hotelId) {
        return ResponseEntity.ok(roomService.saveRoom(room, hotelId));
    }

    // Update room
    @PreAuthorize("hasRole('OWNER') or hasRole('ADMIN')")
    @PutMapping("/{id}")
    public ResponseEntity<Room> updateRoom(@PathVariable Long id,
                                           @RequestParam Long hotelId,
                                           @RequestBody Room room) {
        room.setId(id);
        return ResponseEntity.ok(roomService.saveRoom(room, hotelId));
    }

    // Delete room
    @PreAuthorize("hasRole('OWNER') or hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        roomService.delete(id);
        return ResponseEntity.noContent().build();
    }
}

