package com.cozyhaven.service;

import com.cozyhaven.entity.Booking;
import com.cozyhaven.entity.Hotel;
import com.cozyhaven.entity.Room;
import com.cozyhaven.exception.ResourceNotFoundException;
import com.cozyhaven.repository.HotelRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class HotelService {

    private final HotelRepository hotelRepository;

    public HotelService(HotelRepository hotelRepository) {
        this.hotelRepository = hotelRepository;
    }

    /* ---------- Create / Update ---------- */
    public Hotel saveHotel(Hotel hotel) {
        // Set hotel reference for each room
        hotel.getRooms().forEach(room -> room.setHotel(hotel));
        return hotelRepository.save(hotel);
    }

    public Hotel save(Hotel hotel) {
        return hotelRepository.save(hotel);
    }

    /* ---------- Read ---------- */
    public List<Hotel> findAll() {
        return hotelRepository.findAll();
    }

    public Hotel findById(Long id) {
        return hotelRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Hotel id " + id + " not found"));
    }

    public List<Hotel> getHotelsByOwner(Long ownerId) {
        return hotelRepository.findByOwnerId(ownerId);
    }

    /* ---------- Delete ---------- */
    public void delete(Long id) {
        if (!hotelRepository.existsById(id)) {
            throw new ResourceNotFoundException("Hotel id " + id + " not found");
        }
        hotelRepository.deleteById(id);
    }

    /* ---------- Bookings for Hotel ---------- */
    public List<Booking> getBookingsForHotel(Long hotelId) {
        Hotel hotel = hotelRepository.findById(hotelId)
                .orElseThrow(() -> new ResourceNotFoundException("Hotel not found"));

        return hotel.getRooms().stream()
                .filter(room -> room.getBookings() != null)
                .flatMap(room -> room.getBookings().stream())
                .collect(Collectors.toList());
    }
}
