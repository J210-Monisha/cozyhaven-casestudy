package com.cozyhaven.dto;

import com.cozyhaven.entity.Review;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ReviewDto {
    private Long id;
    private String comment;
    private int rating;
    private String username;
    private String hotelName;
    private String roomType;

    public static ReviewDto fromEntity(Review r) {
        return ReviewDto.builder()
                .id(r.getId())
                .comment(r.getComment())
                .rating(r.getRating())
                .username(r.getUser().getUsername())
                .hotelName(r.getHotel() != null ? r.getHotel().getName() : "N/A")
                .roomType(r.getRoom() != null ? r.getRoom().getBedType() : "N/A")
                .build();
    }
}


