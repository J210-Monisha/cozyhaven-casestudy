package com.cozyhaven.controller;

import com.cozyhaven.dto.HotelDto;
import com.cozyhaven.entity.Booking;
import com.cozyhaven.entity.Hotel;
import com.cozyhaven.entity.User;
import com.cozyhaven.service.HotelService;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/hotels")
@CrossOrigin(origins = "http://localhost:4200")
public class HotelController {

    private final HotelService hotelService;

    public HotelController(HotelService hotelService) {
        this.hotelService = hotelService;
    }

    // 🔓 Public - list all hotels as DTOs
    @PreAuthorize("permitAll()")
    @GetMapping
    public ResponseEntity<List<HotelDto>> list() {
        List<HotelDto> dtoList = hotelService.findAll().stream()
                .map(HotelDto::fromEntity)
                .toList();
        return ResponseEntity.ok(dtoList);
    }

    // 🔓 Public - get hotel by ID as DTO
    @PreAuthorize("permitAll()")
    @GetMapping("/{id}")
    public ResponseEntity<HotelDto> get(@PathVariable Long id) {
        Hotel hotel = hotelService.findById(id);
        return ResponseEntity.ok(HotelDto.fromEntity(hotel));
    }

    // 🔐 Owner/Admin - add new hotel
    @PreAuthorize("hasRole('OWNER') or hasRole('ADMIN')")
    @PostMapping
    public ResponseEntity<Hotel> add(@RequestBody Hotel hotel, Authentication auth) {
        User owner = (User) auth.getPrincipal();
        hotel.setOwner(owner);  // 💡 Set owner before saving
        return ResponseEntity.ok(hotelService.saveHotel(hotel));
    }

    // 🔐 Owner/Admin - update hotel
    @PreAuthorize("hasRole('OWNER') or hasRole('ADMIN')")
    @PutMapping("/{id}")
    public ResponseEntity<Object> updateHotel(@PathVariable Long id, @RequestBody Hotel updatedHotel, Authentication auth) {
        Hotel existing = hotelService.findById(id);
        existing.setName(updatedHotel.getName());
        existing.setLocation(updatedHotel.getLocation());
        existing.setDescription(updatedHotel.getDescription());
        existing.setAmenities(updatedHotel.getAmenities());

        // ✅ Reassign the same owner to avoid null
        User owner = (User) auth.getPrincipal();
        existing.setOwner(owner);

        return ResponseEntity.ok(hotelService.save(existing));
    }

    // 🔐 Owner/Admin - delete hotel
    @PreAuthorize("hasRole('OWNER') or hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        hotelService.delete(id);
        return ResponseEntity.noContent().build();
    }

    // 🔐 Owner/Admin - get hotels owned by current user as DTOs
    @PreAuthorize("hasRole('OWNER') or hasRole('ADMIN')")
    @GetMapping("/owner")
    public ResponseEntity<List<HotelDto>> getHotelsByOwner(Authentication auth) {
        Long ownerId = ((User) auth.getPrincipal()).getId();
        List<HotelDto> dtoList = hotelService.getHotelsByOwner(ownerId).stream()
                .map(HotelDto::fromEntity)
                .toList();
        return ResponseEntity.ok(dtoList);
    }

    // 🔐 Owner/Admin - get bookings for a hotel (already working)
    @PreAuthorize("hasRole('OWNER') or hasRole('ADMIN')")
    @GetMapping("/{id}/bookings")
    public ResponseEntity<?> getBookingsForHotel(@PathVariable Long id, Authentication auth) {
        try {
            Hotel hotel = hotelService.findById(id);
            if (hotel == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Hotel not found.");
            }

            User owner = (User) auth.getPrincipal();
            if (hotel.getOwner() == null || !hotel.getOwner().getId().equals(owner.getId())) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN).body("You are not the owner of this hotel.");
            }

            List<Booking> bookings = hotelService.getBookingsForHotel(id);
            return ResponseEntity.ok(bookings);
        } catch (Exception e) {
            e.printStackTrace();  // 🔍 See exact error in backend console
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(
                    Map.of("message", "Something went wrong", "details", e.getMessage())
            );
        }
    }
}
