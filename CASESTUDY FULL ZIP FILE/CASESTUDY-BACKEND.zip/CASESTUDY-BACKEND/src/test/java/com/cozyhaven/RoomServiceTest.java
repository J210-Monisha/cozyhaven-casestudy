package com.cozyhaven;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.cozyhaven.entity.Hotel;
import com.cozyhaven.entity.Room;
import com.cozyhaven.exception.ResourceNotFoundException;
import com.cozyhaven.repository.HotelRepository;
import com.cozyhaven.repository.RoomRepository;
import com.cozyhaven.service.RoomService;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@ExtendWith(MockitoExtension.class)
public class RoomServiceTest {

    @Mock
    private RoomRepository roomRepo;

    @Mock
    private HotelRepository hotelRepo;

    @InjectMocks
    private RoomService roomService;

    @Test
    void testSaveRoom_Success() {
        Long hotelId = 1L;
        Hotel hotel = new Hotel();
        hotel.setId(hotelId);

        Room room = new Room();
        when(hotelRepo.findById(hotelId)).thenReturn(Optional.of(hotel));
        when(roomRepo.save(any(Room.class))).thenReturn(room);

        Room savedRoom = roomService.saveRoom(room, hotelId);

        assertNotNull(savedRoom);
        verify(hotelRepo).findById(hotelId);
        verify(roomRepo).save(room);
        assertEquals(hotel, room.getHotel()); // check FK set
    }

    @Test
    void testSaveRoom_HotelNotFound() {
        Long hotelId = 1L;
        Room room = new Room();
        when(hotelRepo.findById(hotelId)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> roomService.saveRoom(room, hotelId));
    }

    @Test
    void testFindByHotelId() {
        Long hotelId = 1L;
        List<Room> rooms = Arrays.asList(new Room(), new Room());
        when(roomRepo.findByHotelId(hotelId)).thenReturn(rooms);

        List<Room> result = roomService.findByHotelId(hotelId);

        assertEquals(2, result.size());
        verify(roomRepo).findByHotelId(hotelId);
    }

    @Test
    void testFindById_Success() {
        Room room = new Room();
        room.setId(1L);
        when(roomRepo.findById(1L)).thenReturn(Optional.of(room));

        Room found = roomService.findById(1L);

        assertEquals(1L, found.getId());
        verify(roomRepo).findById(1L);
    }

    @Test
    void testFindById_NotFound() {
        when(roomRepo.findById(1L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> roomService.findById(1L));
    }

}
