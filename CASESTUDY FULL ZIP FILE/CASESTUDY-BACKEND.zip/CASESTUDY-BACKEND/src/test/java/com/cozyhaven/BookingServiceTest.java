package com.cozyhaven;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import com.cozyhaven.entity.*;
import com.cozyhaven.exception.BookingException;
import com.cozyhaven.exception.ResourceNotFoundException;
import com.cozyhaven.repository.BookingRepository;
import com.cozyhaven.repository.RoomRepository;
import com.cozyhaven.repository.UserRepository;
import com.cozyhaven.service.BookingService;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.*;

@ExtendWith(MockitoExtension.class)
public class BookingServiceTest {

    @Mock private BookingRepository bookingRepo;
    @Mock private RoomRepository roomRepo;
    @Mock private UserRepository userRepo;

    @InjectMocks private BookingService bookingService;

    @Test
    void testCalculateFare_NoExtras() {
        Room room = Room.builder()
                .baseFare(1000)
                .maxOccupancyBase(2)
                .maxOccupancy(4)
                .build();

        double fare = bookingService.calculateFare(room, 2, 2, 2);
        assertEquals(2000, fare);
    }

    @Test
    void testCalculateFare_WithExtras() {
        Room room = Room.builder()
                .baseFare(1000)
                .maxOccupancyBase(2)
                .maxOccupancy(4)
                .build();

        // 1 extra adult, 1 extra child, 2 nights
        double fare = bookingService.calculateFare(room, 3, 3, 2);
        // base = 2000, extra adult = 0.4 * 1000 * 2 = 800, child = 0.2 * 1000 * 2 = 400
        assertEquals(3200, fare);
    }

    @Test
    void testBookRoom_Success() {
        Long userId = 1L;
        Long roomId = 10L;

        Room room = Room.builder()
                .id(roomId)
                .baseFare(1000)
                .maxOccupancyBase(2)
                .maxOccupancy(4)
                .available(true)
                .build();

        User user = new User();
        user.setId(userId);

        LocalDate in = LocalDate.now();
        LocalDate out = in.plusDays(2);

        when(roomRepo.findById(roomId)).thenReturn(Optional.of(room));
        when(userRepo.findById(userId)).thenReturn(Optional.of(user));
        when(bookingRepo.save(any(Booking.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Booking booking = bookingService.bookRoom(userId, roomId, in, out, 2, 2);

        assertNotNull(booking);
        assertEquals(user, booking.getUser());
        assertEquals(room, booking.getRoom());
        assertEquals(Booking.Status.BOOKED, booking.getStatus());
        assertFalse(room.isAvailable());

        verify(roomRepo).save(room);
        verify(bookingRepo).save(any(Booking.class));
    }

    @Test
    void testBookRoom_RoomNotFound() {
        when(roomRepo.findById(99L)).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () ->
                bookingService.bookRoom(1L, 99L, LocalDate.now(), LocalDate.now().plusDays(1), 1, 0));
    }

    @Test
    void testBookRoom_RoomAlreadyBooked() {
        Room room = Room.builder().available(false).build();
        when(roomRepo.findById(1L)).thenReturn(Optional.of(room));

        assertThrows(BookingException.class, () ->
                bookingService.bookRoom(1L, 1L, LocalDate.now(), LocalDate.now().plusDays(1), 1, 0));
    }

    @Test
    void testBookRoom_UserNotFound() {
        Room room = Room.builder().available(true).build();
        when(roomRepo.findById(1L)).thenReturn(Optional.of(room));
        when(userRepo.findById(1L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () ->
                bookingService.bookRoom(1L, 1L, LocalDate.now(), LocalDate.now().plusDays(1), 1, 0));
    }

    @Test
    void testGetUserBookings() {
        List<Booking> mockBookings = List.of(new Booking(), new Booking());
        when(bookingRepo.findByUserId(1L)).thenReturn(mockBookings);

        List<Booking> bookings = bookingService.getUserBookings(1L);

        assertEquals(2, bookings.size());
        verify(bookingRepo).findByUserId(1L);
    }

    @Test
    void testCancelBooking_Success() {
        Room room = new Room();
        room.setAvailable(false);

        Booking booking = Booking.builder()
                .id(1L)
                .room(room)
                .status(Booking.Status.BOOKED)
                .build();

        when(bookingRepo.findById(1L)).thenReturn(Optional.of(booking));

        bookingService.cancelBooking(1L);

        assertEquals(Booking.Status.CANCELLED, booking.getStatus());
        assertTrue(room.isAvailable());
    }

    @Test
    void testCancelBooking_NotFound() {
        when(bookingRepo.findById(1L)).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () -> bookingService.cancelBooking(1L));
    }

    @Test
    void testCancelBooking_InvalidStatus() {
        Booking booking = Booking.builder()
                .id(1L)
                .status(Booking.Status.CANCELLED)
                .build();

        when(bookingRepo.findById(1L)).thenReturn(Optional.of(booking));

        assertThrows(BookingException.class, () -> bookingService.cancelBooking(1L));
    }
}
